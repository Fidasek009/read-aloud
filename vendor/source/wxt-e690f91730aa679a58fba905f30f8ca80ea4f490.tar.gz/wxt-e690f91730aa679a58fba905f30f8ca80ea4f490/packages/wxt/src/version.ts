export const version = '{{version}}';
