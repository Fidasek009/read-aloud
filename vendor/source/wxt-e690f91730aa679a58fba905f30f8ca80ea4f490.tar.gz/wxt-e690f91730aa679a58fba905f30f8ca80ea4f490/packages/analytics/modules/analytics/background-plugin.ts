import '#analytics';

export default () => {};
