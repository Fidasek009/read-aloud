import 'wxt';
import 'wxt/utils/define-app-config';
import {
  addAlias,
  addViteConfig,
  addWxtPlugin,
  defineWxtModule,
} from 'wxt/modules';
import { relative, resolve } from 'node:path';
import type { AnalyticsConfig } from './types';
import { normalizePath } from 'wxt';

declare module 'wxt/utils/define-app-config' {
  export interface WxtAppConfig {
    analytics: AnalyticsConfig;
  }
}

export default defineWxtModule({
  name: 'analytics',
  imports: [{ name: 'analytics', from: '#analytics' }],
  setup(wxt) {
    // Paths
    const wxtAnalyticsFolder = resolve(wxt.config.wxtDir, 'analytics');
    const wxtAnalyticsIndex = resolve(wxtAnalyticsFolder, 'index.ts');
    const clientModuleId = process.env.NPM
      ? '@wxt-dev/analytics'
      : resolve(wxt.config.modulesDir, 'analytics/client');
    const pluginModuleId = process.env.NPM
      ? '@wxt-dev/analytics/background-plugin'
      : resolve(wxt.config.modulesDir, 'analytics/background-plugin');

    // Add required permissions
    wxt.hook('build:manifestGenerated', (_, manifest) => {
      manifest.permissions ??= [];
      if (!manifest.permissions.includes('storage')) {
        manifest.permissions.push('storage');
      }
    });

    // Generate #analytics module
    const wxtAnalyticsCode = `import { createAnalytics } from '${
      process.env.NPM
        ? clientModuleId
        : normalizePath(relative(wxtAnalyticsFolder, clientModuleId))
    }';
import { useAppConfig } from '#imports';

export const analytics = createAnalytics(useAppConfig().analytics);
`;
    addAlias(wxt, '#analytics', wxtAnalyticsIndex);
    wxt.hook('prepare:types', async (_, entries) => {
      entries.push({
        path: wxtAnalyticsIndex,
        text: wxtAnalyticsCode,
      });
    });

    // Ensure there is a background entrypoint
    wxt.hook('entrypoints:resolved', (_, entrypoints) => {
      const hasBackground = entrypoints.find(
        (entry) => entry.type === 'background',
      );
      if (!hasBackground) {
        entrypoints.push({
          type: 'background',
          inputPath: 'virtual:user-background',
          name: 'background',
          options: {},
          outputDir: wxt.config.outDir,
          skipped: false,
        });
      }
    });

    // Ensure analytics is initialized in the background only.
    addWxtPlugin(wxt, pluginModuleId, (entry) => entry.type === 'background');

    // Fix issues with dependencies
    addViteConfig(wxt, () => ({
      optimizeDeps: {
        // Ensure the "#analytics" import is processed by vite in the background plugin
        exclude: ['@wxt-dev/analytics'],
      },
    }));
  },
});
