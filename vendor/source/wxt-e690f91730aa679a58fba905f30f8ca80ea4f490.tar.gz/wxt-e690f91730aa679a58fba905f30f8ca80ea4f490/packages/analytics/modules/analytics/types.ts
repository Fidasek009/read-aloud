export interface Analytics {
  /** Report a page change. */
  page: (url: string) => Promise<void>;
  /** Report a custom event. */
  track: (
    eventName: string,
    eventProperties?: Record<string, string | undefined>,
  ) => Promise<void>;
  /**
   * Report an error. Background errors are captured automatically by providers
   * that support exception tracking, use this to report errors from other
   * contexts or errors you've handled yourself.
   */
  captureException: (
    error: unknown,
    properties?: Record<string, string | undefined>,
  ) => Promise<void>;
  /** Save information about the user. */
  identify: (
    userId: string,
    userProperties?: Record<string, string>,
  ) => Promise<void>;
  /**
   * Automatically setup and track user interactions, returning a function to
   * remove any listeners that were setup.
   */
  autoTrack: (root: Document | ShadowRoot | Element) => () => void;
  /** Calls `config.enabled.setValue`. */
  setEnabled: (enabled: boolean) => Promise<void>;
}

export interface AnalyticsConfig {
  /** Array of providers to send analytics to. */
  providers: AnalyticsProvider[];
  /** Enable debug logs and other provider-specific debugging features. */
  debug?: boolean;
  /**
   * Your extension's version, reported alongside events.
   *
   * @default browser.runtime.getManifest().version`.
   */
  version?: string;
  /**
   * Configure how the enabled flag is persisted. Defaults to using
   * `browser.storage.local`.
   */
  enabled?: AnalyticsStorageItem<boolean>;
  /**
   * Configure how the user Id is persisted. Defaults to using
   * `browser.storage.local`.
   */
  userId?: AnalyticsStorageItem<string | undefined>;
  /**
   * Configure how user properties are persisted. Defaults to using
   * `browser.storage.local`.
   */
  userProperties?: AnalyticsStorageItem<Record<string, string>>;
}

export interface AnalyticsStorageItem<T> {
  getValue: () => T | Promise<T>;
  setValue?: (newValue: T) => void | Promise<void>;
}

export type AnalyticsProvider = (
  analytics: Analytics,
  config: AnalyticsConfig,
) => {
  /** Upload a page view event. */
  page: (event: AnalyticsPageViewEvent) => Promise<void>;
  /** Upload a custom event. */
  track: (event: AnalyticsTrackEvent) => Promise<void>;
  /** Upload information about the user. */
  identify: (event: BaseAnalyticsEvent) => Promise<void>;
  /**
   * Upload an exception. When defined, the background will also report
   * unhandled errors and promise rejections.
   */
  exception?: (event: AnalyticsExceptionEvent) => Promise<void>;
};

export interface BaseAnalyticsEvent {
  meta: AnalyticsEventMetadata;
  user: {
    id: string;
    properties: Record<string, string | undefined>;
  };
}

export interface AnalyticsEventMetadata {
  /** Identifier of the session the event was fired from. */
  sessionId: number | undefined;
  /** `Date.now()` of when the event was reported. */
  timestamp: number;
  /** Ex: `"1920x1080"`. */
  screen: string | undefined;
  /** `document.referrer` */
  referrer: string | undefined;
  /** `navigator.language` */
  language: string | undefined;
  /** `location.href` */
  url: string | undefined;
  /** `document.title` */
  title: string | undefined;
}

export interface AnalyticsPageInfo {
  url: string;
  title: string | undefined;
  location: string | undefined;
}

export interface AnalyticsPageViewEvent extends BaseAnalyticsEvent {
  page: AnalyticsPageInfo;
}

export interface AnalyticsTrackEvent extends BaseAnalyticsEvent {
  event: {
    name: string;
    properties?: Record<string, string | undefined>;
  };
}

export interface AnalyticsExceptionEvent extends BaseAnalyticsEvent {
  exception: {
    /** Ex: `"TypeError"`. */
    type: string;
    message: string;
    /** The raw `Error.stack` string, if available. */
    stack: string | undefined;
    /** `false` for unhandled errors and promise rejections. */
    handled: boolean;
    properties?: Record<string, string | undefined>;
  };
}
